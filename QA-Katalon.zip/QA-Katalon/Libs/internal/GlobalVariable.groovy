package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile default : Waits 5 seconds</p>
     */
    public static Object G_Timeout_Small
     
    /**
     * <p>Profile default : Used for User Creation</p>
     */
    public static Object NewUser
     
    /**
     * <p>Profile default : Used for User Creation</p>
     */
    public static Object NewUser2
     
    /**
     * <p>Profile default : QATester Username</p>
     */
    public static Object QATester
     
    /**
     * <p>Profile default : QATester Password (Dev)</p>
     */
    public static Object QATesterPass
     
    /**
     * <p>Profile default : Detailed Report in Dev</p>
     */
    public static Object DetailedModule
     
    /**
     * <p>Profile default : Create Knowledge in Dev</p>
     */
    public static Object CreateKnowledge
     
    /**
     * <p>Profile default : SmoketestCompanyManager Username</p>
     */
    public static Object SmoketestCompanyManager
     
    /**
     * <p>Profile default : SmoketestStudent Username</p>
     */
    public static Object SmoketestStudent
     
    /**
     * <p>Profile default : SmoketestEvaluator Username</p>
     */
    public static Object SmoketestEvaluator
     
    /**
     * <p>Profile default : SmoketestProctor Username</p>
     */
    public static Object SmoketestProctor
     
    /**
     * <p>Profile default : Password for Smoketest Users</p>
     */
    public static Object SmoketestPass
     
    /**
     * <p>Profile default : QATester Password in Prod</p>
     */
    public static Object QATesterPassProd
     
    /**
     * <p>Profile default : Upload Skill in Dev</p>
     */
    public static Object UploadSkill
     
    /**
     * <p>Profile default : User for task testing</p>
     */
    public static Object TaskListTester
     
    /**
     * <p>Profile default : List of Errors</p>
     */
    public static Object errorList
     
    /**
     * <p></p>
     */
    public static Object ExpiredTester
     
    /**
     * <p></p>
     */
    public static Object errorHandling
     
    /**
     * <p></p>
     */
    public static Object QATesterPassQA
     
    /**
     * <p></p>
     */
    public static Object Env
     
    /**
     * <p></p>
     */
    public static Object environmentURL
     
    /**
     * <p></p>
     */
    public static Object qualStatus
     
    /**
     * <p></p>
     */
    public static Object RecordCount
     
    /**
     * <p></p>
     */
    public static Object LegacyTaskProfile
     
    /**
     * <p></p>
     */
    public static Object SmoketestAdmin
     
    /**
     * <p></p>
     */
    public static Object SmoketestAdminPW
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            G_Timeout_Small = selectedVariables['G_Timeout_Small']
            NewUser = selectedVariables['NewUser']
            NewUser2 = selectedVariables['NewUser2']
            QATester = selectedVariables['QATester']
            QATesterPass = selectedVariables['QATesterPass']
            DetailedModule = selectedVariables['DetailedModule']
            CreateKnowledge = selectedVariables['CreateKnowledge']
            SmoketestCompanyManager = selectedVariables['SmoketestCompanyManager']
            SmoketestStudent = selectedVariables['SmoketestStudent']
            SmoketestEvaluator = selectedVariables['SmoketestEvaluator']
            SmoketestProctor = selectedVariables['SmoketestProctor']
            SmoketestPass = selectedVariables['SmoketestPass']
            QATesterPassProd = selectedVariables['QATesterPassProd']
            UploadSkill = selectedVariables['UploadSkill']
            TaskListTester = selectedVariables['TaskListTester']
            errorList = selectedVariables['errorList']
            ExpiredTester = selectedVariables['ExpiredTester']
            errorHandling = selectedVariables['errorHandling']
            QATesterPassQA = selectedVariables['QATesterPassQA']
            Env = selectedVariables['Env']
            environmentURL = selectedVariables['environmentURL']
            qualStatus = selectedVariables['qualStatus']
            RecordCount = selectedVariables['RecordCount']
            LegacyTaskProfile = selectedVariables['LegacyTaskProfile']
            SmoketestAdmin = selectedVariables['SmoketestAdmin']
            SmoketestAdminPW = selectedVariables['SmoketestAdminPW']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
